package Assignment_104;

public class task_one {

}
